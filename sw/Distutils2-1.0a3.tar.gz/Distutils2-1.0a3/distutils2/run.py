from distutils2.core import setup

if __name__ == '__main__':
    setup()
