"""distutils2.converter.fixers

Contains all fixers for the converter.
"""
